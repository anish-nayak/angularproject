import {Component} from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector:'landing',
    templateUrl:'./landing.components.html',
    styleUrls:['./landing.components.css']

})

 
export class LandingComponent{
  
}