
export class Result{
    serialno:number;
    electionId:number;
    candidateId:number;
    voteCount:number;
    resultStatus:number;

    
}